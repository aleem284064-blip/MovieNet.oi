from flask import Flask, render_template, request, redirect, session, url_for
from datetime import timedelta

app = Flask(__name__)
app.secret_key = "supersecret"
app.permanent_session_lifetime = timedelta(days=7)

# Dummy movies (replace with DB fetch)
movies = [
    {"title": "Movie One", "lang": "hindi", "overview": "First Hindi Movie", "year": 2025, "poster": "https://via.placeholder.com/400x200", "watch": "#"},
    {"title": "Movie Two", "lang": "english", "overview": "English Blockbuster", "year": 2025, "poster": "https://via.placeholder.com/400x200", "watch": "#"}
]

admin_email = "admin@example.com"
admin_pass = "607094Ss@"

@app.route("/")
def home():
    latest = movies[0] if movies else None
    return render_template("home.html", movies=movies, latest=latest)

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        if email == admin_email and password == admin_pass:
            session["user"] = "admin"
            return redirect(url_for("admin_panel"))
        elif email and password:  # normal user
            session["user"] = email
            return redirect(url_for("home"))
        else:
            return render_template("login.html", error="Invalid credentials")
    return render_template("login.html")

@app.route("/admin")
def admin_panel():
    if session.get("user") == "admin":
        return render_template("admin.html", movies=movies)
    return redirect(url_for("login"))

@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect(url_for("home"))

if __name__ == "__main__":
    app.run(debug=True)
